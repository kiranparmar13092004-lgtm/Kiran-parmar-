# Kiran Parmar Android App (Starter Project)

यह Android Studio के लिए शुरुआती प्रोजेक्ट है। थीम लाल/काली है और इसमें:
- Gallery से वीडियो चुनने का विकल्प
- फोन के कैमरे से वीडियो रिकॉर्ड करने का विकल्प (फोन के कैमरा ऐप के जरिए)
- चुने/रिकॉर्ड किए गए वीडियो को डिवाइस पर वीडियो प्लेयर में खोलना

## APK कैसे बनाएं
1. ZIP को कंप्यूटर पर Extract करें।
2. Android Studio में `KiranParmarAndroid` फ़ोल्डर खोलें।
3. Gradle sync पूरा होने दें और आवश्यक Android SDK डाउनलोड करें।
4. `Build > Build Bundle(s) / APK(s) > Build APK(s)` चुनें।
5. APK आम तौर पर `app/build/outputs/apk/debug/app-debug.apk` में मिलेगा।

## ज़रूरी सीमाएँ
यह अभी starter/demo app है, पूरा YouTube जैसा प्लेटफॉर्म नहीं।
- दूसरे यूज़र्स के अकाउंट, ऑनलाइन वीडियो फीड, लाइक/कमेंट/सब्सक्राइब सिंक करने के लिए backend API और database चाहिए।
- वीडियो अपलोड/स्ट्रीमिंग के लिए सुरक्षित storage, transcoding और access control चाहिए।
- Monetization के लिए अलग भुगतान/विज्ञापन व्यवस्था और स्पष्ट नियम चाहिए।
- असली रिलीज़ से पहले सुरक्षा, privacy policy, content reporting/moderation और डिवाइस पर परीक्षण ज़रूरी है।

## Build environment
Android Studio, JDK 17, Android SDK 35.


## ऑनलाइन backend starter (Firebase)
प्रोजेक्ट में `FirebaseVideoRepository.kt`, `firestore.rules` और `storage.rules` जोड़े गए हैं। Repository में Email/Password registration/sign-in, वीडियो Storage upload + Firestore metadata, नवीनतम वीडियो सूची और per-user like toggle के starter methods हैं। ये methods अभी demo UI से जुड़े नहीं हैं; Firebase setup के बाद UI से connect करना होगा।

### Firebase जोड़ना
1. Firebase Console में नया project बनाएं और Android app package `com.kiranparmar.app` जोड़ें।
2. डाउनलोड किया हुआ `google-services.json` को `app/` फ़ोल्डर में रखें।
3. Project-level `build.gradle.kts` में plugins block के अंदर `id("com.google.gms.google-services") version "4.4.2" apply false` जोड़ें।
4. `app/build.gradle.kts` के plugins block में `id("com.google.gms.google-services")` जोड़ें।
5. Firebase Console में Authentication > Email/Password enable करें; Firestore Database और Storage बनाएं।
6. Firebase Rules स्क्रीन में इस प्रोजेक्ट के `firestore.rules` और `storage.rules` की rules publish करें।
7. Android Studio से build करें और real device पर upload/download टेस्ट करें।

### सुरक्षा / production notes
- Included rules शुरुआती उदाहरण हैं; public read का अर्थ है प्रकाशित वीडियो metadata और storage objects को कोई भी पढ़ सकता है। निजी वीडियो चाहिए तो access rules बदलें।
- App Check, upload rate limits, file moderation, reporting, comment spam protection, privacy policy, account deletion, server-side validation और storage cost limits production से पहले जोड़ें।
- APK अभी यहाँ से prebuilt नहीं है; Firebase config और Android build environment के बिना final APK नहीं बनती।
