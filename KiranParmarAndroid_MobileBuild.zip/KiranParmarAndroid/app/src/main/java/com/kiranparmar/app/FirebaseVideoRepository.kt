package com.kiranparmar.app

import android.net.Uri
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.storage.FirebaseStorage
import java.util.UUID

/**
 * Firebase repository starter for online creator videos.
 *
 * Before using it:
 * 1) Add your Firebase project's google-services.json to app/
 * 2) Configure the Google Services Gradle plugin per README_HI.md
 * 3) Enable Email/Password authentication, Firestore, and Storage in Firebase Console.
 * 4) Apply the included firestore.rules and storage.rules.
 *
 * This class is intentionally separate from the demo UI. Connect it to UI after
 * Firebase is configured; never ship unrestricted database/storage rules.
 */
class FirebaseVideoRepository {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()
    private val storage = FirebaseStorage.getInstance()

    fun register(email: String, password: String, displayName: String, onResult: (Result<String>) -> Unit) {
        auth.createUserWithEmailAndPassword(email.trim(), password)
            .addOnSuccessListener { result ->
                val user = result.user ?: run {
                    onResult(Result.failure(IllegalStateException("User account was not created")))
                    return@addOnSuccessListener
                }
                val profile = mapOf(
                    "uid" to user.uid,
                    "displayName" to displayName.trim(),
                    "email" to email.trim(),
                    "createdAt" to System.currentTimeMillis()
                )
                db.collection("users").document(user.uid).set(profile)
                    .addOnSuccessListener { onResult(Result.success(user.uid)) }
                    .addOnFailureListener { onResult(Result.failure(it)) }
            }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun signIn(email: String, password: String, onResult: (Result<String>) -> Unit) {
        auth.signInWithEmailAndPassword(email.trim(), password)
            .addOnSuccessListener { result ->
                val uid = result.user?.uid
                if (uid == null) onResult(Result.failure(IllegalStateException("Sign-in returned no user")))
                else onResult(Result.success(uid))
            }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun uploadVideo(uri: Uri, title: String, description: String, onResult: (Result<String>) -> Unit) {
        val user = auth.currentUser
        if (user == null) {
            onResult(Result.failure(IllegalStateException("Please sign in first")))
            return
        }
        val videoId = UUID.randomUUID().toString()
        val videoRef = storage.reference.child("videos/${user.uid}/$videoId.mp4")
        videoRef.putFile(uri)
            .continueWithTask { task ->
                if (!task.isSuccessful) throw (task.exception ?: IllegalStateException("Upload failed"))
                videoRef.downloadUrl
            }
            .addOnSuccessListener { downloadUri ->
                val data = mapOf(
                    "videoId" to videoId,
                    "ownerUid" to user.uid,
                    "title" to title.trim(),
                    "description" to description.trim(),
                    "videoUrl" to downloadUri.toString(),
                    "createdAt" to System.currentTimeMillis(),
                    "likeCount" to 0L
                )
                db.collection("videos").document(videoId).set(data)
                    .addOnSuccessListener { onResult(Result.success(videoId)) }
                    .addOnFailureListener { onResult(Result.failure(it)) }
            }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun loadLatestVideos(onResult: (Result<List<Map<String, Any>>>) -> Unit) {
        db.collection("videos")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(50)
            .get()
            .addOnSuccessListener { snapshot ->
                onResult(Result.success(snapshot.documents.mapNotNull { doc -> doc.data }))
            }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun likeVideo(videoId: String, onResult: (Result<Unit>) -> Unit) {
        val user = auth.currentUser
        if (user == null) {
            onResult(Result.failure(IllegalStateException("Please sign in first")))
            return
        }
        val likeRef = db.collection("videos").document(videoId)
            .collection("likes").document(user.uid)
        db.runTransaction { transaction ->
            val existing = transaction.get(likeRef)
            if (existing.exists()) {
                transaction.delete(likeRef)
            } else {
                transaction.set(likeRef, mapOf("uid" to user.uid, "createdAt" to System.currentTimeMillis()))
            }
            null
        }.addOnSuccessListener { onResult(Result.success(Unit)) }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }
}
