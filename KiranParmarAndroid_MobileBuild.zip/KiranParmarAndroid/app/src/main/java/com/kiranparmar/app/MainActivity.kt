package com.kiranparmar.app

import androidx.activity.ComponentActivity
import android.content.ContentValues
import android.text.InputType
import android.widget.EditText
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private lateinit var list: LinearLayout
    private var pendingCameraUri: Uri? = null
    private var signedInUser: String? = null
    private val red = Color.rgb(255, 48, 48)
    private val bg = Color.rgb(15, 15, 15)
    private val panel = Color.rgb(28, 28, 28)
    private val white = Color.WHITE
    private val muted = Color.rgb(180, 180, 180)

    private val galleryPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) addVideo(uri, "Gallery video")
    }

    private val cameraCapture = registerForActivityResult(ActivityResultContracts.CaptureVideo()) { success ->
        val uri = pendingCameraUri
        if (success && uri != null) addVideo(uri, "Camera recording")
        else if (uri != null) {
            try { contentResolver.delete(uri, null, null) } catch (_: Exception) {}
            toast("वीडियो रिकॉर्ड नहीं हुआ। दोबारा कोशिश करें।")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildLoginScreen()
    }

    private fun buildLoginScreen() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(bg)
        }
        outer.addView(TextView(this).apply {
            text = "▶ KIRAN PARMAR"
            textSize = 29f
            setTextColor(red)
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
        }, matchWrap())
        outer.addView(TextView(this).apply {
            text = "अपने वीडियो चैनल में आपका स्वागत है"
            textSize = 16f
            setTextColor(white)
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(24))
        }, matchWrap())

        val name = EditText(this).apply {
            hint = "आपका नाम"
            setSingleLine(true)
            setTextColor(white)
            setHintTextColor(muted)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(panel)
        }
        outer.addView(name, matchWrap())

        val email = EditText(this).apply {
            hint = "ईमेल (डेमो)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            setSingleLine(true)
            setTextColor(white)
            setHintTextColor(muted)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(panel)
        }
        outer.addView(email, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(10)
        })

        val enter = makeButton("आगे बढ़ें")
        enter.setOnClickListener {
            val user = name.text.toString().trim()
            if (user.isBlank()) {
                toast("कृपया अपना नाम लिखें।")
            } else {
                signedInUser = user
                buildScreen()
            }
        }
        outer.addView(enter, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)).apply {
            topMargin = dp(16)
        })
        outer.addView(TextView(this).apply {
            text = "डेमो लॉगिन: यह स्क्रीन वास्तविक अकाउंट या पासवर्ड सत्यापित नहीं करती। ऑनलाइन अकाउंट के लिए सुरक्षित authentication server जोड़ना होगा।"
            textSize = 12f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(20), 0, 0)
        }, matchWrap())
        setContentView(outer)
    }

    private fun buildScreen() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(16), dp(12), dp(16), dp(16))
        }

        val brand = TextView(this).apply {
            text = "▶  KIRAN PARMAR"
            textSize = 25f
            setTextColor(red)
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(14))
        }
        outer.addView(brand)
        val welcome = TextView(this).apply {
            text = "नमस्ते, ${signedInUser ?: "Creator"}  •  Demo account"
            textSize = 13f
            setTextColor(muted)
            setPadding(0, 0, 0, dp(10))
        }
        outer.addView(welcome)
        val banner = TextView(this).apply {
            text = "आपका वीडियो चैनल\nMusic • Timli • Dayro • Comedy"
            textSize = 21f
            setTextColor(white)
            setPadding(dp(18), dp(22), dp(18), dp(22))
            setBackgroundColor(Color.rgb(93, 17, 17))
        }
        outer.addView(banner, matchWrap())

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(14), 0, dp(10))
        }
        val gallery = makeButton("＋ Gallery से वीडियो")
        gallery.setOnClickListener { galleryPicker.launch("video/*") }
        val camera = makeButton("● वीडियो रिकॉर्ड")
        camera.setOnClickListener { recordVideo() }
        buttons.addView(gallery, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginEnd = dp(6) })
        buttons.addView(camera, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginStart = dp(6) })
        outer.addView(buttons)

        val socialActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(2), 0, dp(10))
        }
        val like = makeButton("♡ Like")
        like.setOnClickListener {
            val liked = like.text.toString().contains("♥")
            like.text = if (liked) "♡ Like" else "♥ Liked"
        }
        val comment = makeButton("Comment")
        comment.setOnClickListener {
            val input = EditText(this).apply { hint = "अपना कमेंट लिखें" }
            android.app.AlertDialog.Builder(this)
                .setTitle("डेमो कमेंट")
                .setView(input)
                .setPositiveButton("पोस्ट करें") { _, _ ->
                    val value = input.text.toString().trim()
                    if (value.isNotEmpty()) toast("डेमो कमेंट: $value")
                }
                .setNegativeButton("रद्द करें", null)
                .show()
        }
        val subscribe = makeButton("Subscribe")
        subscribe.setOnClickListener {
            subscribe.text = if (subscribe.text.toString() == "Subscribed") "Subscribe" else "Subscribed"
        }
        socialActions.addView(like, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(4) })
        socialActions.addView(comment, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(4); marginEnd = dp(4) })
        socialActions.addView(subscribe, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(4) })
        outer.addView(socialActions)

        val hint = TextView(this).apply {
            text = "अपने वीडियो चुनें या कैमरे से रिकॉर्ड करें। अभी वीडियो इस डिवाइस पर ही खुलेंगे; दूसरे यूज़र्स तक पहुँचाने के लिए सर्वर और डेटाबेस जोड़ना होगा।"
            textSize = 13f
            setTextColor(muted)
            setPadding(0, dp(4), 0, dp(14))
        }
        outer.addView(hint)

        val heading = TextView(this).apply {
            text = "आपके वीडियो"
            textSize = 20f
            setTextColor(white)
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, dp(8), 0, dp(10))
        }
        outer.addView(heading)

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this)
        scroll.addView(list)
        outer.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(outer)
        showEmptyState()
    }

    private fun recordVideo() {
        try {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "KiranParmar_${System.currentTimeMillis()}.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/KiranParmar")
                }
            }
            pendingCameraUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            val uri = pendingCameraUri
            if (uri == null) {
                toast("कैमरा शुरू नहीं हो पाया।")
                return
            }
            cameraCapture.launch(uri)
        } catch (_: Exception) {
            toast("इस डिवाइस पर वीडियो कैमरा उपलब्ध नहीं है।")
        }
    }

    private fun addVideo(uri: Uri, source: String) {
        if (list.childCount == 1 && (list.getChildAt(0) as? TextView)?.text?.toString()?.startsWith("अभी कोई") == true) {
            list.removeAllViews()
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(panel)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        val title = TextView(this).apply {
            text = "▶  ${source}"
            textSize = 17f
            setTextColor(white)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        card.addView(title)
        val subtitle = TextView(this).apply {
            text = uri.lastPathSegment ?: "वीडियो चुना गया"
            textSize = 12f
            setTextColor(muted)
            setPadding(0, dp(6), 0, dp(10))
        }
        card.addView(subtitle)
        val play = makeButton("वीडियो चलाएँ")
        play.setOnClickListener {
            try {
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "video/*")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(intent)
            } catch (_: Exception) {
                toast("वीडियो चलाने के लिए कोई compatible player नहीं मिला।")
            }
        }
        card.addView(play, matchWrap())
        val params = matchWrap().apply { bottomMargin = dp(10) }
        list.addView(card, params)
    }

    private fun showEmptyState() {
        list.removeAllViews()
        list.addView(TextView(this).apply {
            text = "अभी कोई वीडियो नहीं जोड़ा गया।\nऊपर दिए बटन से Gallery या Camera चुनें।"
            textSize = 15f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(28), dp(18), dp(28))
        })
    }

    private fun makeButton(label: String) = Button(this).apply {
        text = label
        textSize = 13f
        isAllCaps = false
        setTextColor(white)
        setBackgroundColor(red)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
